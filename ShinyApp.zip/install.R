# change working directory to the "ShinyApp" directory where files are located

install.packages("shinyAppFunctions_1.0.tar.gz", repos = NULL, type = "source")

install.packages("shiny")
install.packages("ggplot2")
install.packages("markdown")
install.packages("DT")
install.packages("shinythemes")
install.packages("shinycssloaders")
install.packages("MASS")
install.packages("reshape2")
install.packages("grid")
install.packages("MCMCpack")
install.packages("shinyalert")
install.packages("dplyr")
install.packages("shinyjs")
install.packages("beepr")
install.packages("coda")